from django.shortcuts import render
from api.models import Test
from rest_framework import viewsets
from api.serializers import TestSerializer
from django.conf import settings
from django.http import JsonResponse,HttpResponse,StreamingHttpResponse
from django.http import FileResponse
import os

# Create your views here.


class TestViewSet(viewsets.ModelViewSet):
    queryset = Test.objects.all()
    serializer_class = TestSerializer

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


def get_upload_filename(request):
    if request.method == "POST":
        uuid = request.POST.get("filename")
        upload_dir = os.path.join(settings.UPLOAD_DIR,uuid)
        filenames = os.listdir(upload_dir)
        return JsonResponse({"lines":filenames})


def get_file(request):
    if request.method == "POST":
        filename = request.POST.get("filename")
        with open(os.path.join(settings.UPLOAD_DIR,filename),'r') as f:
            lines = f.readlines()
        return JsonResponse({"lines":lines})

def get_file_name(request):
    if request.method == "POST":
        uuid = request.POST.get("uuid")
        upload_dir = os.path.join(settings.UPLOAD_DIR,uuid)
        dir_names = os.listdir(upload_dir)
        return JsonResponse({"lines":dir_names})

def download_file(request):
    if request.method == "GET":
        filename = request.GET.get('filename')
        file_name = request.GET.get("file_name")
        filenames = os.path.join(filename,file_name)
        dir_name = settings.UPLOAD_DIR
        file_path = os.path.join(dir_name,filenames)
        file = open(file_path, 'rb')
        response = FileResponse(file)
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment;filename="{}"'.format(file_name)
        return response
    if request.method == "POST":
        filename = request.POST.get("filename")
        names = filename.rsplit('/',1)[1]
        dir_name = settings.UPLOAD_DIR
        file_path = os.path.join(dir_name,filename)
        file = open(file_path, 'rb')
        response = FileResponse(file)
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment;filename="{}"'.format(names)
        return response
