from django.contrib.auth.models import User,Group
from rest_framework import serializers
from api.models import Test

class TestSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Test
        # fields = ('id',"key1","key2")
        fields = ('id',"stack","user","time","mem_free","mem_used","version","miei","idfa","playerid","playername","game")
