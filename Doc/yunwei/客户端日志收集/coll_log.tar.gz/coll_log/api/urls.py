from django.conf.urls import url,include
from rest_framework import routers
from . import views

# router = routers.DefaultRouter()
# router.register(r'test',views.TestViewSet)


urlpatterns = [
    # url(r"^get_api/",include('api.urls')),
    # url(r'^',include(router.urls)),
    url(r"^get_file/",views.get_file),
    url(r"^get_file_name/",views.get_file_name),
    url(r"^get_filenames/",views.get_upload_filename),
    url(r"^download/",views.download_file)
]
