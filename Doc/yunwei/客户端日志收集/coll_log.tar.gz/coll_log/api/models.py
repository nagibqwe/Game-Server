from django.db import models

# Create your models here.

class Test(models.Model):
    stack = models.CharField(max_length=5000,default="")
    user = models.CharField(max_length=5000,default="")
    time = models.CharField(max_length=5000,default="")
    mem_free = models.CharField(max_length=5000,default="")
    mem_used = models.CharField(max_length=5000,default="")
    version = models.CharField(max_length=5000,default="")
    miei = models.CharField(max_length=5000,default="")
    idfa = models.CharField(max_length=5000,default="")
    playerid = models.CharField(max_length=5000,default="")
    playername = models.CharField(max_length=5000,default="")
    uuid = models.CharField(max_length=5000,default="")
    game = models.CharField(max_length=5000,default="")

    def __str__(self):
        return self.user