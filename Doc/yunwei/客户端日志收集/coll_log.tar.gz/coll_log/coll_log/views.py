from django.shortcuts import render
from django.conf import settings
import os
from api.models import Test

# Create your views here.


def upload_log(request):
    if request.method == "GET":
        obj = Test.objects.all().order_by("-id")[:20]
        return render(request,'upload_log.html',{"obj":obj})

    if request.method == "POST":
        up_dir = settings.UPLOAD_DIR
        user = request.POST.get("user")
        time = request.POST.get("time")
        mem_free = request.POST.get("mem_free")
        mem_used = request.POST.get("mem_used")
        version = request.POST.get("version")
        miei = request.POST.get("miei")
        idfa = request.POST.get("idfa")
        playerid = request.POST.get("playerid")
        playername = request.POST.get("playername")
        uuid = request.POST.get("uuid")
        game = request.POST.get("game")
        file_obj = request.FILES.get("stack","")
        logPath = request.POST.get("logPath")
        try :
            logpath = logPath.split('/')[1].replace(" ", "_")
        except Exception as e:
            logpath = logPath.split('\\')[1].replace(" ","_")
        print(logpath)
        print(up_dir,user,time,mem_free,mem_used,version,miei,idfa,playerid,playername,uuid,game,file_obj,logPath,logpath)
        if not os.path.isdir(os.path.join(up_dir,uuid)):
            os.mkdir(os.path.join(up_dir,uuid))
        upload_dir = os.path.join(os.path.join(up_dir,uuid),logpath)
        print(upload_dir)
        try:
            test = Test.objects.filter(uuid=uuid).filter(playername=playername)[0]
            test.time = time
            test.save()
        except Exception as e:
            upload_info = Test(user=user,time=time,mem_free=mem_free,mem_used=mem_used,version=version,miei=miei,idfa=idfa,playerid=playerid,playername=playername,game=game,uuid=uuid,stack='查看')
            upload_info.save()
        # Dir_name.objects.update_or_create(uuid=uuid,dir_name=logpath)
        file_obj = request.FILES.get("stack","")
        print(file_obj)
        if not os.path.isdir(upload_dir):
            os.mkdir(upload_dir)
        if file_obj != '':
            f = open(os.path.join(upload_dir,file_obj.name),"wb+")
            for chunk in file_obj.chunks():
                f.write(chunk)
            f.close()
        return render(request,"upload_log.html")

